/*
 * oneExonPosition.cpp
 *
 *  Created on: 28.10.2015
 *      Author: AlexanderDilthey
 */

#include "oneExonPosition.h"

namespace hla {


} /* namespace hla */

#!/bin/bash
scl enable devtoolset-1.1 bash

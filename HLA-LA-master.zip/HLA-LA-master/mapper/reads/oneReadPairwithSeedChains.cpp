/*
 * oneReadPairwithSeedChains.cpp
 *
 *  Created on: 22.09.2015
 *      Author: AlexanderDilthey
 */

#include "oneReadPairwithSeedChains.h"

namespace mapper {
namespace reads {

oneReadPair_withSeedChains::oneReadPair_withSeedChains() {
	// TODO Auto-generated constructor stub

}

oneReadPair_withSeedChains::~oneReadPair_withSeedChains() {
	// TODO Auto-generated destructor stub
}

} /* namespace reads */
} /* namespace mapper */

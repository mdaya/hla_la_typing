/*
 * oneReadPair.cpp
 *
 *  Created on: 21.09.2015
 *      Author: AlexanderDilthey
 */

#include "oneReadPair.h"

namespace mapper {
namespace reads {

oneReadPair::oneReadPair() {
	// TODO Auto-generated destructor stub
}

oneReadPair::~oneReadPair() {
	// TODO Auto-generated destructor stub
}

} /* namespace reads */
} /* namespace mapper */

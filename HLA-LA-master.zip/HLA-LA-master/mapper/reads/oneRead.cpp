/*
 * oneRead.cpp
 *
 *  Created on: 21.09.2015
 *      Author: AlexanderDilthey
 */

#include "oneRead.h"

namespace mapper {
namespace reads {

oneRead::~oneRead() {
	// TODO Auto-generated destructor stub
}

} /* namespace reads */
} /* namespace mapper */

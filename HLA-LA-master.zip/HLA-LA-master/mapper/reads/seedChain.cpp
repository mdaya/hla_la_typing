/*
 * seedChain.cpp
 *
 *  Created on: 21.09.2015
 *      Author: AlexanderDilthey
 */

#include "seedChain.h"

namespace mapper {
namespace reads {
seedChain::~seedChain() {
	// TODO Auto-generated destructor stub
}
}
} /* namespace mapper */

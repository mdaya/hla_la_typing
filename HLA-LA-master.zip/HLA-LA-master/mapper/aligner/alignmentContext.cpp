/*
 * alignmentContext.cpp
 *
 *  Created on: 28.09.2015
 *      Author: AlexanderDilthey
 */

#include "alignmentContext.h"

namespace mapper {
namespace aligner {

alignmentContext::alignmentContext() {
	aligner = 0;
	sequence = 0;
}

alignmentContext::~alignmentContext() {
	// TODO Auto-generated destructor stub
}

} /* namespace aligner */
} /* namespace mapper */
